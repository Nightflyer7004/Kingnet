# KingNet – Mappa dell’universo narrativo di Stephen King

**KingNet** è una mappa interattiva che mostra i collegamenti tra i personaggi, i romanzi e gli universi narrativi creati da **Stephen King**.

## 🔍 Funzionalità
- Visualizza oltre 50 personaggi da più di 30 romanzi
- Filtra per universi narrativi (Derry, Castle Rock, Torre Nera…)
- Motore di ricerca interno
- Rete interattiva (grafo) basata su vis.js

## 🌐 Versione online
👉 [Apri KingNet nel browser](https://nightflyer7004.github.io/Kingnet/)

## ✅ Come usare
1. Carica `index.html` nel tuo repository GitHub
2. Attiva GitHub Pages dalle impostazioni
3. Il sito sarà visibile all'indirizzo:  
   `https://tuonome.github.io/Kingnet`

---

Creato da Alessandro (Nightflyer7004) – 2025
